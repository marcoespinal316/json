package com.ejemplos.ejemplo02.activity;

import android.support.v4.app.FragmentActivity;

/**
 * Created by user on 20/06/2016.
 */
public class BaseActivity extends FragmentActivity
{

}
