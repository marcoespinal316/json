package com.ejemplos.ejemplo02.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.ejemplos.ejemplo02.Constants;
import com.ejemplos.ejemplo02.R;

import org.json.JSONObject;

public class ClientsFragment extends Fragment
{
    private TextView txtResults;
    private ListView lstClients;
    private ProgressBar progressBar;

    private RequestQueue requestQueue;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_client_volleyjson_example, container, false);

        progressBar = (ProgressBar)view.findViewById(R.id.marker_progress_example);
        progressBar.setVisibility(View.VISIBLE);

        // Crear el RequestQueue de Volley
        requestQueue = Volley.newRequestQueue(getContext());

        // Casteando el resultado en el TextView
        txtResults = (TextView)view.findViewById(R.id.textview_results);

        // Creando el JSONRequest
        JsonObjectRequest objreq = new JsonObjectRequest(Request.Method.GET, Constants.strJsonURL, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response)
                {
                    try {
                        progressBar.setVisibility(View.GONE);

                        JSONObject obj = response.getJSONObject("colorObject");

                        String color = obj.getString("colorName");
                        String desc = obj.getString("description");

                        String strData = "";

                        strData += "Color Name:" + color +
                                "\nDescription: " + desc;

                        txtResults.setText(strData);
                    }
                    catch(Exception e)
                    {
                        progressBar.setVisibility(View.GONE);
                        e.printStackTrace();
                    }
                }
            },
            new Response.ErrorListener()
            {
                @Override
                public void onErrorResponse(VolleyError error)
                {
                    progressBar.setVisibility(View.GONE);

                    Log.e("Volley", "Error");
                }
            }
        );

        requestQueue.add(objreq);

        return view;
    }
}
