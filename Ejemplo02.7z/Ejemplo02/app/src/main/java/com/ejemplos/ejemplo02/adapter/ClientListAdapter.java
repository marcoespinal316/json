package com.ejemplos.ejemplo02.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.ejemplos.ejemplo02.Ejemplo02Volley;
import com.ejemplos.ejemplo02.R;
import com.ejemplos.ejemplo02.activity.MainActivity;
import com.ejemplos.ejemplo02.bean.Client;
import com.ejemplos.ejemplo02.widgets.CustomImageView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by user on 10/06/2016.
 */
public class ClientListAdapter extends BaseAdapter
{
    private List<Client> clients;
    private MainActivity mainActivity;

    public ClientListAdapter(MainActivity mainActivity, ArrayList<Client> listClient)
    {
        this.mainActivity = mainActivity;
        clients = listClient;
    }

    @Override
    public int getCount()
    {
        return clients.size();
    }

    @Override
    public Client getItem(int position)
    {
        return clients.get(position);
    }

    @Override
    public long getItemId(int position)
    {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        ClientHolder holder = null;

        Client entity = (Client)getItem(position);

        if (convertView != null)
        {
            holder = (ClientHolder) convertView.getTag();
        }
        else
        {
            convertView = LayoutInflater.from(mainActivity).inflate(R.layout.item_client_listview, parent, false);

            holder = new ClientHolder();
            holder.nombre = (TextView) convertView.findViewById(R.id.textview_name);
            holder.cargo = (TextView) convertView.findViewById(R.id.textview_position);
            holder.imageView = (CustomImageView) convertView.findViewById(R.id.imageview_list_client);

            convertView.setTag(holder);
        }

        holder.nombre.setText(entity.getNombre() + " " + entity.getApellido());
        holder.cargo.setText(entity.getCargo());

        holder.imageView.setImageUrl(entity.getImagen(), Ejemplo02Volley.getImageLoader());
        holder.imageView.setDefaultImageResId(R.drawable.ticket_imagen);

        return convertView;
    }

    static class ClientHolder
    {
        TextView nombre, cargo;
        CustomImageView imageView;
    }

    public void setClients(List<Client> clients)
    {
        this.clients = clients;

        notifyDataSetChanged();
    }
}
