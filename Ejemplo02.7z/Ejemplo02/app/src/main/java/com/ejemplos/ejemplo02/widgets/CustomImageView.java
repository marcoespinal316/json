package com.ejemplos.ejemplo02.widgets;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.util.AttributeSet;

import com.android.volley.toolbox.NetworkImageView;

import com.ejemplos.ejemplo02.R;

public class CustomImageView extends NetworkImageView
{
	private float imageWidth, imageHeight;

    private static final int FADE_IN_TIME_MS = 500;
    
	public CustomImageView(Context context) {
		super(context);
	}

	public CustomImageView(Context context, AttributeSet attrs) {
		super(context, attrs);
		_customize(context, attrs);
	}

	public CustomImageView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		_customize(context, attrs);
		
	}

	private void _customize(Context ctx, AttributeSet attrs) {
		TypedArray attributes = ctx.obtainStyledAttributes(attrs, R.styleable.CustomImageExtras);
		imageWidth = attributes.getDimension(R.styleable.CustomImageExtras_dim_width, 0);
		imageHeight = attributes.getDimension(R.styleable.CustomImageExtras_dim_height, 0);
		attributes.recycle();
	}
	
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		if (imageWidth == 0) {
			imageWidth = getMeasuredWidth();
		}
		if (imageHeight == 0) {
			imageHeight = getMeasuredHeight();
		}
		setMeasuredDimension((int)imageWidth, (int) imageHeight);
	}
	
	@Override
    public void setImageBitmap(Bitmap bm) {
		super.setImageBitmap(bm);
    }
}
