package com.ejemplos.ejemplo02.activity;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.widget.TextView;

import com.ejemplos.ejemplo02.R;
import com.ejemplos.ejemplo02.fragment.MainFragment;

/**
 * Created by user on 24/05/2016.
 */
public class MainActivity extends FragmentActivity
{
    private TextView btnClientsList;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Fragment fragment = new MainFragment();
        Bundle bundle = new Bundle();
        fragment.setArguments(bundle);
        getSupportFragmentManager().beginTransaction().replace(R.id.content_frame, fragment).commit();
    }
}
