package com.ejemplos.ejemplo02.bean;

import java.util.List;

/**
 * Created by user on 13/06/2016.
 */
public class Clients
{
    private List<Client> clientes;

    // Get y Set
    public List<Client> getClientes()
    {
        return clientes;
    }

    public void setClientes(List<Client> clientes)
    {
        this.clientes = clientes;
    }
}
