package com.ejemplos.ejemplo02.fragment;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.ejemplos.ejemplo02.R;

/**
 * Created by user on 8/06/2016.
 */
public class MainFragment extends Fragment
{
    private TextView txtBtnClients;
    private TextView txtBtnClientsArray;
    private TextView txtBtnClientsList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_main, container, false);

        txtBtnClients = (TextView) view.findViewById(R.id.textview_clients);
        txtBtnClientsArray = (TextView) view.findViewById(R.id.textview_clients_array);
        txtBtnClientsList = (TextView) view.findViewById(R.id.textview_clients_adapter);

        txtBtnClients.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Bundle bundle = new Bundle();
                Fragment fragment = new ClientsFragment();
                fragment.setArguments(bundle);
                getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.content_frame, fragment).addToBackStack(null).commit();
            }
        });

        txtBtnClientsArray.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Bundle bundle = new Bundle();
                Fragment fragment = new ClientsArrayFragment();
                fragment.setArguments(bundle);
                getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.content_frame, fragment).addToBackStack(null).commit();
            }
        });

        txtBtnClientsList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Bundle bundle = new Bundle();
                Fragment fragment = new ClientListFragment();
                fragment.setArguments(bundle);
                getFragmentManager().beginTransaction().replace(R.id.content_frame, fragment).addToBackStack(null).commit();
            }
        });

        return view;
    }
}
