package com.ejemplos.ejemplo02.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.volley.toolbox.NetworkImageView;
import com.ejemplos.ejemplo02.Constants;
import com.ejemplos.ejemplo02.Ejemplo02Volley;
import com.ejemplos.ejemplo02.R;
import com.ejemplos.ejemplo02.bean.Client;
import com.ejemplos.ejemplo02.widgets.CustomImageView;

import org.w3c.dom.Text;

/**
 * Created by user on 13/06/2016.
 */
public class DetailClientFragment extends Fragment
{
    private TextView txtName;
    private TextView txtDescription;
    private CustomImageView imgDetalleClient;
    private Client entity;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstantState)
    {
        View view = inflater.inflate(R.layout.fragment_detail_client, container, false);

        txtName = (TextView) view.findViewById(R.id.textview_detail_client_name);
        txtDescription = (TextView) view.findViewById(R.id.textview_detail_client_description);
        imgDetalleClient = (CustomImageView) view.findViewById(R.id.imgAvatar);

        try
        {
            entity = getArguments().getParcelable(Constants.KEY_PARAMS_ENTITY);

            txtName.setText(entity.getNombre() + " " + entity.getApellido());
            txtDescription.setText(entity.getDescripcion());

            imgDetalleClient.setImageUrl(entity.getImagen(), Ejemplo02Volley.getImageLoader());
            imgDetalleClient.setDefaultImageResId(R.drawable.ticket_imagen);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        return view;
    }
}
