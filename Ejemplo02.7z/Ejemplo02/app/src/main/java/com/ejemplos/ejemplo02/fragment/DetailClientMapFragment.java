package com.ejemplos.ejemplo02.fragment;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.ejemplos.ejemplo02.Constants;
import com.ejemplos.ejemplo02.R;
import com.ejemplos.ejemplo02.Util;
import com.ejemplos.ejemplo02.bean.Client;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by user on 30/06/2016.
 */
public class DetailClientMapFragment extends Fragment implements OnMapReadyCallback, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, LocationListener
{
    private Client client;
    private MapView mapView;
    private GoogleMap mGoogleMap;
    private GoogleApiClient mGoogleApiClient;
    private Polyline polyline;
    private LatLng m_point;
    private Location location;
    private LocationManager locationManager;
    private ArrayList<Marker> markers;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_client_map, container, false);

        try
        {
            client = (Client) getArguments().get(Constants.KEY_PARAMS_ENTITY);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        markers = new ArrayList<Marker>();

        mapView = (MapView) view.findViewById(R.id.mapview_client_detail_map);
        mapView.onCreate(savedInstanceState);

        //viewMapa();

        //---------

        return view;
    }



    @Override
    public void onResume()
    {
        mapView.onResume();
        super.onResume();
    }

    @Override
    public void onDestroy()
    {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    public void onLowMemory()
    {
        super.onLowMemory();
        mapView.onLowMemory();
    }

    @Override
    public void onConnected(@Nullable Bundle bundle)
    {

    }

    @Override
    public void onConnectionSuspended(int i)
    {

    }

    @Override
    public void onLocationChanged(Location location)
    {

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras)
    {

    }

    @Override
    public void onProviderEnabled(String provider)
    {

    }

    @Override
    public void onProviderDisabled(String provider)
    {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult)
    {

    }

    // Mi ubicación cuando el Mapa esté listo
    @Override
    public void onMapReady(GoogleMap googleMap)
    {

    }


    // Búsqueda de la ruta entre los puntos de origen y destino
    class SearchGoogleMapsPoints extends AsyncTask<Location, Void, String>
    {

        @Override
        protected String doInBackground(Location... location) {
            String strUrl = makeURL(location[0].getLatitude(), location[0].getLongitude(), m_point.latitude, m_point.longitude);

            // List<NameValuePair> nvps = new ArrayList<NameValuePair>();

            String strPoints = "";

            try
            {
                strPoints  = Util.getHttpRequestGet(strUrl);
            }
            catch (Exception e)
            {
                strPoints = null;
                e.printStackTrace();
            }


//        	drawPath(strPoints);
            return strPoints;
        }

        protected void onPostExecute(String strPoints)
        {
            drawPath(strPoints);

            if (location != null)
            {
                //Calculate the markers to get their position
                LatLngBounds.Builder b = new LatLngBounds.Builder();

                for (Marker m : markers)
                {
                    b.include(m.getPosition());
                }
                b.include(new LatLng(location.getLatitude(), location.getLongitude()));

                LatLngBounds bounds = b.build();
                //Change the padding as per needed
                CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, 10);
                mGoogleMap.animateCamera(cu);
            }
        }
    }

    // Crear la URL del servicio para obtener la ruta
    public String makeURL(double sourcelat, double sourcelog, double destlat, double destlog)
    {
        StringBuilder urlString = new StringBuilder();
        urlString.append("http://maps.googleapis.com/maps/api/directions/json");
        urlString.append("?origin=");// from
        urlString.append(Double.toString(sourcelat));
        urlString.append(",");
        urlString.append(Double.toString(sourcelog));
        urlString.append("&destination=");// to
        urlString.append(Double.toString(destlat));
        urlString.append(",");
        urlString.append(Double.toString(destlog));
        urlString.append("&sensor=false&mode=driving&alternatives=true");
        return urlString.toString();
    }

    public void drawPath(String result) {

        try {
            // Tranform the string into a json object
            final JSONObject json = new JSONObject(result);
            JSONArray routeArray = json.getJSONArray("routes");
            JSONObject routes = routeArray.getJSONObject(0);
            JSONObject overviewPolylines = routes.getJSONObject("overview_polyline");
            String encodedString = overviewPolylines.getString("points");
            List<LatLng> list = Util.decodePoly(encodedString);

            for (int z = 0; z < list.size() - 1; z++) {
                LatLng src = list.get(z);
                LatLng dest = list.get(z + 1);
                Polyline line = mGoogleMap.addPolyline(new PolylineOptions().add(new LatLng(src.latitude, src.longitude),
                        new LatLng(dest.latitude, dest.longitude)).width(4).color(ContextCompat.getColor(getActivity(), R.color.ejemplo_green)).geodesic(true));
            }

        } catch (JSONException e) {

        }
    }
}
