package com.ejemplos.ejemplo02;

import android.app.Application;

/**
 * Created by user on 16/06/2016.
 */
public class Ejemplo02App extends Application
{
    @Override
    public void onCreate()
    {
        super.onCreate();
        init();
    }

    private void init()
    {
        Ejemplo02Volley.init(this);
    }
}
