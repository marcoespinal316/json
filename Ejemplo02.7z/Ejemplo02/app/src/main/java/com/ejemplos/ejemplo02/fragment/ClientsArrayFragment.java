package com.ejemplos.ejemplo02.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.ejemplos.ejemplo02.Constants;
import com.ejemplos.ejemplo02.R;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Created by user on 9/06/2016.
 */
public class ClientsArrayFragment extends Fragment
{
    private TextView txtResultArray;
    private ProgressBar progressBar;

    private RequestQueue requestQueue;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_client_volleyjson_example2, container, false);

        progressBar = (ProgressBar)view.findViewById(R.id.marker_progress_example_array);
        progressBar.setVisibility(View.VISIBLE);

        txtResultArray = (TextView) view.findViewById(R.id.textview_results_array);

        // Crear el RequestQueue de Volley
        requestQueue = Volley.newRequestQueue(getContext());

        // Procesando el Request
        JsonArrayRequest arrayreq = new JsonArrayRequest(Constants.strJsonURL2, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response)
            {
                progressBar.setVisibility(View.GONE);

                try
                {
                    JSONObject colorObj = response.getJSONObject(0);

                    JSONArray jsonArrayColor = colorObj.getJSONArray("colorArray");

                    String strJsonData = "";

                    for (int i = 0; i < jsonArrayColor.length(); i++)
                    {
                        JSONObject jsonObjectColor = jsonArrayColor.getJSONObject(i);

                        String color = jsonObjectColor.getString("colorName");
                        String hex = jsonObjectColor.getString("hexValue");

                        strJsonData += "Color Number " + (i + 1) + "\nColor Name: " + color +
                            "\nHex Value: " + hex + "\n\n\n";

                        txtResultArray.setText(strJsonData);
                    }
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error)
                    {
                        progressBar.setVisibility(View.GONE);
                        Log.e("Volley","Error");
                    }
                }
        );

        requestQueue.add(arrayreq);

        return view;
    }
}
