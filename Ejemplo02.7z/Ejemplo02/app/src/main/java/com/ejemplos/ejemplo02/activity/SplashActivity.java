package com.ejemplos.ejemplo02.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.ejemplos.ejemplo02.Constants;
import com.ejemplos.ejemplo02.R;

/**
 * Created by user on 14/06/2016.
 */
public class SplashActivity extends Activity
{
    private boolean mTimeFinished = false;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run()
            {
                mTimeFinished = true;
                openNextScreen();
            }
        }, Constants.TIME_SPLASH_DISPLAY_LENGTH);
    }

    private void openNextScreen()
    {
        if (mTimeFinished)
        {
            finish();
            Intent intent = new Intent();
            intent.setClassName(this, MainActivity.class.getName());
            startActivity(intent);
        }
    }
}
