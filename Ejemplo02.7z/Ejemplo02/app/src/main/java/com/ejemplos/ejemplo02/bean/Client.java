package com.ejemplos.ejemplo02.bean;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by user on 10/06/2016.
 */
public class Client implements Parcelable
{
    private long codigo;
    private String nombre;
    private String apellido;
    private String cargo;
    private String imagen;
    private String latitud;
    private String longitud;
    private String descripcion;

    // Get y Set
    public long getCodigo()
    {
        return codigo;
    }

    public void setCodigo(long codigo)
    {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre)
    {
        this.nombre = nombre;
    }

    public String getApellido()
    {
        return apellido;
    }

    public void setApellido(String apellido)
    {
        this.apellido = apellido;
    }

    public String getCargo()
    {
        return cargo;
    }

    public void setCargo(String cargo)
    {
        this.cargo = cargo;
    }

    public String getImagen()
    {
        return imagen;
    }

    public void setImagen(String imagen)
    {
        this.imagen = imagen;
    }

    public String getLatitud()
    {
        return latitud;
    }

    public void setLatitud(String latitud)
    {
        this.latitud = latitud;
    }

    public String getLongitud()
    {
        return longitud;
    }

    public void setLongitud(String longitud)
    {
        this.longitud = longitud;
    }

    public String getDescripcion()
    {
        return descripcion;
    }

    public void setDescripcion(String descripcion)
    {
        this.descripcion = descripcion;
    }

    @Override
    public int describeContents()
    {
        return hashCode();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
        dest.writeLong(this.codigo);
        dest.writeString(this.nombre);
        dest.writeString(this.apellido);
        dest.writeString(this.cargo);
        dest.writeString(this.imagen);
        dest.writeString(this.latitud);
        dest.writeString(this.longitud);
        dest.writeString(this.descripcion);
    }

    public Client()
    {

    }

    private Client(Parcel in)
    {
        this.codigo = in.readLong();
        this.nombre = in.readString();
        this.apellido = in.readString();
        this.cargo = in.readString();
        this.imagen = in.readString();
        this.latitud = in.readString();
        this.longitud = in.readString();
        this.descripcion = in.readString();
    }

    public static final Creator<Client> CREATOR = new Creator<Client>() {
        @Override
        public Client createFromParcel(Parcel source)
        {
            return new Client(source);
        }

        @Override
        public Client[] newArray(int size)
        {
            return new Client[0];
        }
    };
}
