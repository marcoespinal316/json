package com.ejemplos.ejemplo02;

/**
 * Created by user on 8/06/2016.
 */
public class Constants
{
    // Application Name
    public static final String APPLICATION_NAME = "Ejemplo02";

    public static final String strJsonURL = "https://raw.githubusercontent.com/ianbar20/JSON-Volley-Tutorial/master/Example-JSON-Files/Example-Object.JSON";
    public static final String strJsonURL2 = "https://raw.githubusercontent.com/ianbar20/JSON-Volley-Tutorial/master/Example-JSON-Files/Example-Array.JSON";
    public static final String strJsonURL3 = "https://raw.githubusercontent.com/marcoespinal316/json/master/clientes.json";

    // Codes Parcable
    public static final String KEY_PARAMS_ENTITY = "ENTITY_PARAM";

    // Splash
    public static final int TIME_SPLASH_DISPLAY_LENGTH = 2000;
}
