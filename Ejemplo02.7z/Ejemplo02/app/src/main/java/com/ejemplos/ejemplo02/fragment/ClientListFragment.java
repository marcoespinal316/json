package com.ejemplos.ejemplo02.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.ejemplos.ejemplo02.Constants;
import com.ejemplos.ejemplo02.R;
import com.ejemplos.ejemplo02.activity.MainActivity;
import com.ejemplos.ejemplo02.adapter.ClientListAdapter;
import com.ejemplos.ejemplo02.bean.Client;
import com.ejemplos.ejemplo02.bean.Clients;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by user on 10/06/2016.
 */
public class ClientListFragment extends Fragment
{
    private ListView listView;
    private ClientListAdapter adapter;
    private ProgressBar progressBar;
    private List<Client> lstClients;

    private RequestQueue requestQueue;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstantState)
    {
        View view = inflater.inflate(R.layout.fragment_clients, container, false);


        progressBar = (ProgressBar) view.findViewById(R.id.marker_progress);
        listView = (ListView) view.findViewById(R.id.client_listview);

        adapter = new ClientListAdapter((MainActivity) getActivity(), new ArrayList<Client>());

        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                Client client =  adapter.getItem(position);

                Bundle bundle = new Bundle();
                bundle.putParcelable(Constants.KEY_PARAMS_ENTITY, client);

                Fragment fragment = new DetailClientFragment();
                fragment.setArguments(bundle);
                getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.content_frame, fragment).addToBackStack(null).commit();
            }
        });

        getData();

        return view;
    }

    private void getData()
    {
        progressBar.setVisibility(View.VISIBLE);
        listView.setVisibility(View.GONE);

        // Crear el RequestQueue de Volley
        requestQueue = Volley.newRequestQueue(getContext());

        // Procesando el Request
        JsonObjectRequest objreq = new JsonObjectRequest(Request.Method.GET, Constants.strJsonURL3, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response)
            {
                try {
                    progressBar.setVisibility(View.GONE);
                    listView.setVisibility(View.VISIBLE);

                    lstClients = new ArrayList<Client>();

                    Gson parser = new Gson();
                    Clients clients = parser.fromJson(response.toString(), Clients.class);
                    List<Client> lstClientResponse = clients.getClientes();

                    for (Client client : lstClientResponse)
                    {
                        lstClients.add(client);
                    }

                    adapter.setClients(lstClients);
                    adapter.notifyDataSetChanged();
                }
                catch(Exception e)
                {
                    progressBar.setVisibility(View.GONE);
                    e.printStackTrace();
                }
            }
        },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error)
                    {
                        progressBar.setVisibility(View.GONE);

                        Log.e("Volley", "Error");
                    }
                }
        );

        requestQueue.add(objreq);
    }
}
